﻿using System;
namespace SemesterTest1
{
	public abstract class SummaryStrategy
	{
		public abstract void PrintSummary(List<int> numbers);
	}
}

